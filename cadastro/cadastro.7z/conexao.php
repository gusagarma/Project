<?php
$servidor = "localhost";
$usuario = "root";
$senha  = "";
$dbname = "cadastro";

//Conexão
$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);
